%%%% initial conditions
m=1; mper=1;                                %mass of central mass point and perturber
a=1; aper=10; e=0.2; eper=0.2;    %semi-major axis and eccentricity
inc=110/180*pi; Om=pi; om=0;    %inc=inclination, Om=\Omega, om=\omega
f=0;                                                 %true anomaly of perturber
ep_Oct=a/aper*eper/(1-eper^2);   %Octupole coefficient \epsilon_{Oct{
ep_SA=(a/aper/(1-eper^2))^(3/2)*mper/sqrt((m+mper)*m);
                                                        %CDA coefficient
                                                        %\epsilon_{SA}
                                                       
CDA_on=1; % 1:CDA,  0:DA 
IPC_on=1;   % 1 include Initial Phase Correction,  0 ignore it.


%%%% Calculating The Long term evolution
% time grid with the KLC time scale as the unit of tau
dtau=0.03;%5;               %time step
taumax=100;                     %total integration time
tau=0:dtau:taumax;       %time grid

%Create and initilize the variables that will contain the results of the integration
N=length(tau);bar_j_e_vec=zeros(N,6);j_e_vec=zeros(N,6);

%input initial value
j_e_vec(1,:)=[sqrt(1-e^2)*[sin(inc)*sin(Om),-sin(inc)*cos(Om),cos(inc)],...
    e*[-sin(om)*cos(inc)*sin(Om)+cos(om)*cos(Om),...
        sin(om)*cos(inc)*cos(Om)+cos(om)*sin(Om),sin(inc)*sin(om)]];

%initial phase correction IPC
bar_j_e_vec(1,:)=j_e_vec(1,:);
if IPC_on
    for iteration=1:2 %iteratively solve the equation for initial phase correction,
        %2 iterations is more than enough
        j_e_vec_oscilliation = Quadrupole_Pout_Oscillation( ep_SA,eper,bar_j_e_vec(1,:),f );
        bar_j_e_vec(1,:)=j_e_vec(1,:)-j_e_vec_oscilliation;
    end
end


%numerical integration of the CDA using fourth-order Runge-Kutta
for i=2:1:N
    k1=dtau*CDA_Derivative(CDA_on*ep_SA,ep_Oct,eper,bar_j_e_vec(i-1,:));
    k2=dtau*CDA_Derivative(CDA_on*ep_SA,ep_Oct,eper,bar_j_e_vec(i-1,:)+k1/2);
    k3=dtau*CDA_Derivative(CDA_on*ep_SA,ep_Oct,eper,bar_j_e_vec(i-1,:)+k2/2);
    k4=dtau*CDA_Derivative(CDA_on*ep_SA,ep_Oct,eper,bar_j_e_vec(i-1,:)+k3);
    bar_j_e_vec(i,:)=bar_j_e_vec(i-1,:)+k1/6+k2/3+k3/3+k4/6;
end

% resulting jz
bar_jz=bar_j_e_vec(:,3);%slowly evolving component
% calculating the envelope of the oscilations of jz
[jz_max,jz_min] = Quadrupole_Pout_Oscillation_jz_maxmin(ep_SA,eper,bar_j_e_vec(:,1:3),bar_j_e_vec(:,4:6));


%%%% Calculating The Short term oscilations for a short interval
% choosing range of outer true anomaly
f=[0:0.01:4/ep_SA];
% calculating the mean anomaly of the outer orbit
eperf=f*0+eper;                     % grid of (equal) outer ecentricities 
E=Kepler_E_of_f_e(f,eperf);     %calculating the eccentric anomaly
M=E-eper*sin(E);                    %calculating the mean anomaly

j_e_vec=zeros(length(f),6);

for lf=1:length(f);
    tauf=f(lf)*ep_SA;
    bar_j_e_vecf=interp1(tau,bar_j_e_vec,tauf);    % interpolating the values of the slowly varying components
     j_e_vec(lf,:) = Quadrupole_Pout_Oscillation( ep_SA,eper,bar_j_e_vecf,f(lf));
        %j_e_vec_oscilliation is the fast oscillating component
end

% resulting jz
jz=j_e_vec(:,3);%Including fast oscillating component




%make plot comparing the results
plot(M*ep_SA,jz,'-c');hold on;   %tau equals ep_SA*M
plot(tau,bar_jz,'-m');hold on;
plot(tau,jz_max,'-c');hold on;
plot(tau,jz_min,'-c');hold on;

h1=xlabel('$\frac{\epsilon_{SA}\times f}{t_{sec}}$'); h2=ylabel('$j_z$');
h3=legend('$j_z$ = $\bar{j_z}$ + fast oscillating component','$\bar{j_z}$ = slowly evolving component');

set(h1,'interpreter','latex','Fontsize',15);
set(h2,'interpreter','latex','Fontsize',15);
set(h3,'interpreter','latex','Fontsize',15);