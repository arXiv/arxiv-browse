function [ j_e_vec] = Quadrupole_Pout_Oscillation( ep_SA,eper,bar_j_e_vec,f )
%calculate the fast oscillating component from slowly evolving component bar_j_e_vec
%derived from quadrupole Single Averaged equation
%slowly evolving components: bar_j_e_vec = [bar_jx,bar_jy,bar_jz,bar_ex,bar_ey,bar_ez]
%total: j_e_vec = bar_j_e_vec + j_e_vec_oscilliation

jx=bar_j_e_vec(1);jy=bar_j_e_vec(2);jz=bar_j_e_vec(3);
ex=bar_j_e_vec(4);ey=bar_j_e_vec(5);ez=bar_j_e_vec(6);

a = [3/4*(-5*ey*ez + jy*jz), 3/4*(5*ex*ez - jx*jz), 0, ...
    -(3/4)*(3*ez*jy + ey*jz), 3/4*(3*ez*jx + ex*jz), 3/2*(ey*jx - ex*jy)];
b = [3/8*(-5*ex*ez + jx*jz), 3/8*(5*ey*ez - jy*jz), 3/8*(5*ex^2 - 5*ey^2 - jx^2 + jy^2), ...
    3/8*(ez*jx - 5*ex*jz), 3/8*(-ez*jy + 5*ey*jz), 3/2*(ex*jx - ey*jy)];
c = [3/8*(5*ey*ez - jy*jz), 3/8*(5*ex*ez - jx*jz), 3/4*(-5*ex*ey + jx*jy), ...
    3/8*(-ez*jy + 5*ey*jz), 3/8*(-ez*jx + 5*ex*jz), -(3/2)*(ey*jx + ex*jy)];

jvevsin1 = ep_SA*eper*(a + c);
jvevcos1 = -ep_SA*eper*b;
jvevsin2 = ep_SA*c;
jvevcos2 = -ep_SA*b;
jvevsin3 = ep_SA*eper*c/3;
jvevcos3 = -ep_SA*eper*b/3;

j_e_vec_oscilliation = jvevsin1*sin(f)+jvevcos1*cos(f)+jvevsin2*sin(2*f)+...
    jvevcos2*cos(2*f)+jvevsin3*sin(3*f)+jvevcos3*cos(3*f);

j_e_vec=bar_j_e_vec+j_e_vec_oscilliation;

end

