function [jz_oscmax,jz_oscmin] = Quadrupole_Pout_Oscillation_jz_maxmin(ep_SA,eper,jt,et)
%calculate the fast oscillating component from slowly evolving component bar_j_e_vec
%derived from quadrupole Single Averaged equation
%slowly evolving components: bar_j_e_vec = [bar_jx,bar_jy,bar_jz,bar_ex,bar_ey,bar_ez]
%total: j_e_vec = bar_j_e_vec + j_e_vec_oscilliation

jx=jt(:,1);jy=jt(:,2);jz=jt(:,3);
ex=et(:,1);ey=et(:,2);ez=et(:,3);

C = 3/8*(5*ex.^2 - 5*ey.^2 - jx.^2 + jy.^2);
S = 3/4*(-5*ex.*ey + jx.*jy);

jz_oscmax=jz+ep_SA*sqrt(C.^2+S.^2).*(1+sqrt(1-C./sqrt(C.^2+S.^2))/sqrt(2)*4/3*eper);
jz_oscmin=jz-ep_SA*sqrt(C.^2+S.^2).*(1+sqrt(1+C./sqrt(C.^2+S.^2))/sqrt(2)*4/3*eper);


% sin1 = ep_SA*eper*S;
% cos1 = -ep_SA*eper*C;
% sin2 = ep_SA*S;
% cos2 = -ep_SA*C;
% sin3 = ep_SA*eper*S/3;
% cos3 = -ep_SA*eper*C/3;
% om_osc=atan2(S,-C);
%jz_osc = sin1.*sin(ft)+cos1.*cos(ft)+sin2.*sin(2*ft)+...
%    cos2.*cos(2*ft)+sin3.*sin(3*ft)+cos3.*cos(3*ft);

end

