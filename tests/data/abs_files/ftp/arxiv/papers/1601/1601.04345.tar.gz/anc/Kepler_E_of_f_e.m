function [E]=Kepler_E_of_f_e(ft,et)
cosf=cos(ft);
j2=1-et.^2;
r=j2./(1+et.*cosf);
sinE=r.*sin(ft)./sqrt(j2);
cosE=r.*cosf+et;
E=atan2(sinE,cosE);
E=E+round((ft-E)/2/pi)*2*pi;
end